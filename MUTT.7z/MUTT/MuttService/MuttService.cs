﻿using Topshelf;
/// <summary>
/// Matt's Utility Tray Tool Service
/// </summary>
namespace MuttService
{
    public class MuttService
    {
        public static void Main()
        {
            HostFactory.Run(x =>                                 
            {
                x.Service<MuttService>(s =>                      
                {
                    s.ConstructUsing(name => new MuttService()); 
                    s.WhenStarted(tc => tc.Start());             
                    s.WhenStopped(tc => tc.Stop());              
                });
                x.RunAsLocalSystem();                            

                x.SetDescription("M.U.T.T. Service Host");        
                x.SetDisplayName("M.U.T.T. Service Host");                       
                x.SetServiceName("MuttService");                       
            });                                                  
        }

        public void Start()
        {
            
        }

        public void Stop()
        {
            
        }
    }
}
