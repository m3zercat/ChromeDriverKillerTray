﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PM_IIS_Config_Manager;

namespace UnitTestProject1
{
    [TestClass]
    public class InternetInformationServicesManagerTests
    {
        private InternetInformationServicesManager iism;
        private string repoPath;

        [TestInitialize]
        public void BeforeTests()
        {
            iism = new InternetInformationServicesManager();
            repoPath = @"C:\S\NISA_1_1";
        }

        [TestMethod]
        public void TestAppPoolConfigs()
        {
            var validity = iism.CheckDefaultAppPoolConfiguration();
            Assert.AreEqual(Validity.None, validity);
        }

        [TestMethod]
        public void TestSiteConfigs()
        {
            var isAllValid = iism.CheckSiteConfigs(repoPath);
            Assert.IsTrue(isAllValid);
        }

        [TestMethod]
        public void FixSiteConfigs()
        {
            iism.ConfigureSites(repoPath);
            Assert.IsTrue(true);// test passes if no exception
        }
    }
}
