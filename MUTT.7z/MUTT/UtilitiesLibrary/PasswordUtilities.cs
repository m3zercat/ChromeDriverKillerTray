﻿using System;
using System.DirectoryServices.AccountManagement;
using System.Security.Principal;

namespace UtilitiesLibrary
{
    public static class PasswordUtilities
    {
        public static bool ValidateCredentials(string password)
        {
            var user = WindowsIdentity.GetCurrent();
            if (user == null)
            {
                throw new Exception("Unable to determine current user!");
            }
            return ValidateCredentials(user.Name, password);
        }

        public static bool ValidateCredentials(string username, string password)
        {
            bool valid;
            using (var context = new PrincipalContext(ContextType.Domain))
            {
                valid = context.ValidateCredentials(username, password);
            }
            return valid;
        }
    }
}
