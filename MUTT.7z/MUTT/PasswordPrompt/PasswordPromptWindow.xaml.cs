﻿using System.Windows;
using UtilitiesLibrary;

namespace PasswordPrompt
{
    /// <summary>
    /// Interaction logic for PasswordPromptWindow.xaml
    /// </summary>
    public partial class PasswordPromptWindow : Window
    {

        public string Username
        {
            get;
            private set;
        }

        public string Password
        {
            get;
            private set;
        }

        public bool Success
        {
            get; 
            private set;
        }

        public PasswordPromptWindow(string name)
        {
            Username = name;
            InitializeComponent();
            SaveButton.IsEnabled = false;
            BoxLabel.Content = "Enter the password for "+name;
            Success = false;
        }

        public bool IsValidPassword()
        {
            return PasswordUtilities.ValidateCredentials(Username, NewPasswordBox.Password);
        }

        private void PasswordBox_OnPasswordChanged(object sender, RoutedEventArgs e)
        {
            SaveButton.IsEnabled = true;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (IsValidPassword())
            {
                Success = true;
                Password = NewPasswordBox.Password;
                this.Close();
            }
            SaveButton.IsEnabled = false;
        }
    }
}
