﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using Microsoft.Web.Administration;
using PasswordPrompt;
using UtilitiesLibrary;

namespace PM_IIS_Config_Manager
{
    //https://blog.lextudio.com/2015/05/whats-microsoft-web-administration-and-the-horrible-facts-you-should-know/

    public class InternetInformationServicesManager : IDisposable
    {
        private const string HostName = "localhost";
        private const string AppPoolName = "DefaultAppPool";

        private ServerManager _manager;

        public InternetInformationServicesManager()
        {
            Reconnect();
        }

        private void Reconnect()
        {
            if (_manager != null)
            {
                _manager.Dispose();
            }
            _manager = ServerManager.OpenRemote(HostName);
        }

        public void Dispose()
        {
            _manager.Dispose();
        }
        
        public Validity CheckDefaultAppPoolConfiguration(bool checkPassword = false)
        {
            var appPool = _manager.ApplicationPools[AppPoolName];

            var userModel = WindowsIdentity.GetCurrent();
            var userNameMatches = userModel == null || appPool.ProcessModel.UserName == userModel.Name;
            if (!userNameMatches)
            {
                return Validity.UserName;
            }

            if (checkPassword)
            {
                var validCredentials = PasswordUtilities.ValidateCredentials(appPool.ProcessModel.UserName, appPool.ProcessModel.Password);
                if (!validCredentials)
                {
                    return Validity.Password;
                }
            }

            foreach (var appPoolAttribute in appPool.Attributes)
            {
                Debug.WriteLine("\t" + appPoolAttribute.Name + ": " + appPoolAttribute.Value);
            }
            return Validity.None;
        }

        public void ConfigureDefaultAppPool()
        {
            var userName = GetUserName();

            var passwordPromptWindow = new PasswordPromptWindow(userName);
            passwordPromptWindow.ShowDialog();
            if (!passwordPromptWindow.Success)
            {
                throw new IncorrectPasswordException();
            }

            var appPool = _manager.ApplicationPools[AppPoolName];

            appPool.ProcessModel.UserName = passwordPromptWindow.Username;
            appPool.ProcessModel.Password = passwordPromptWindow.Password;

            SaveChanges();
            Reconnect();
        }

        private static string GetUserName()
        {
            var userModel = WindowsIdentity.GetCurrent();
            if (userModel == null)
            {
                throw new UnableToDetectUserException();
            }
            var userName = userModel.Name;
            return userName;
        }

        private void SaveChanges()
        {
            _manager.CommitChanges();
        }

        private static readonly Dictionary<string,WebsiteConfig> WebSiteConfigs = new Dictionary<string,WebsiteConfig>()
        {
              {
                  @"Default Web Site", new WebsiteConfig(@"Default Web Site", @"C:\inetpub\wwwroot").WithPorts(80).WithSslPorts(443).WithWebDirectoryConfigs(
                          new WebApplicationConfig(@"/AdminPlus.Host", @"AdminPlusServices\AdminPlus.Host")
                        , new WebApplicationConfig(@"/External.Applications", @"User Interfaces\External.Applications")
                        , new WebApplicationConfig(@"/Internal.Website", @"User Interfaces\Internal.Website")
                        , new WebApplicationConfig(@"/JavaScriptTests", @"User Interfaces\Internal.Website.JsTests")
                        , new WebApplicationConfig(@"/MyAccount", @"MyAccount\MyAccount")
                        , new WebApplicationConfig(@"/MyAccount Administration", @"MyAccount\MyAccount Administration")
                        , new WebApplicationConfig(@"/MyAccountServices", @"MyAccount.Services\MyAccount.Services.Host")
                        , new WebApplicationConfig(@"/MyAccountServices.Host", @"MyAccount.Services\MyAccount.Services.Host")
                        , new WebApplicationConfig(@"/ServiceProxy", @"Service Proxy\ServiceProxy")
                        , new WebApplicationConfig(@"/Services.Host", @"Enterprise Integration\Services.Host")
                    )
            }
            ,
            {
                @"External.Applications", new WebsiteConfig(@"External.Applications", @"User Interfaces\External.Applications").WithSslPorts(44302)
            }
        };


        public bool CheckSiteConfigs(string branchPath)
        {
            var allValid = true;
            foreach (var site in _manager.Sites.Where(site => WebSiteConfigs.ContainsKey(site.Name)))
            {
                var isSiteValid = CheckSiteConfig(branchPath, site);
                if (!isSiteValid)
                {
                    Debug.WriteLine("Site: "+site.Name+" is not valid!");
                    allValid = false;
                    ConfigureSite(branchPath, site);
                }
            }
            return allValid;
        }

        private bool CheckSiteConfig(string branchPath, Site site)
        {
            var websiteConfig = WebSiteConfigs[site.Name];
            var otherApplications = site.Applications.Where(app => !websiteConfig.WebApplicationConfigs.ContainsKey(app.Path));
            foreach (var otherApp in otherApplications)
            {
                Debug.WriteLine("Other Application Found: " +otherApp.Path);
            }

            var existingApplicationPaths = site.Applications.Select(app=> app.Path);

            var missingAppConfigs = websiteConfig.WebApplicationConfigs.Keys.Where(key => !existingApplicationPaths.Contains(key)).ToList();
            foreach (var appPath in missingAppConfigs)
            {
                Debug.WriteLine("Missing Application: "+appPath);
                return false;
            }
            var existingAppConfigs = websiteConfig.WebApplicationConfigs.Keys.Where(key => existingApplicationPaths.Contains(key));
            foreach (var existingAppPath in existingAppConfigs)
            {
                var appConfig = websiteConfig.WebApplicationConfigs[existingAppPath];
                var application = site.Applications.First(app => app.Path == existingAppPath);
                if (application.ApplicationPoolName != appConfig.AppPoolName)
                {
                    Debug.WriteLine("Expected AppPool: "+appConfig.AppPoolName+" but got: "+application.ApplicationPoolName);
                    return false;
                }
                if (application.VirtualDirectories.Count() != 1)
                {
                    Debug.WriteLine("Expected 1 Virtual Directory but found: " + application.VirtualDirectories.Count());
                    return false;
                }
                if (application.VirtualDirectories[0].Path != "/")
                {
                    Debug.WriteLine("Expected Virtual Directory Path to be '/' but found: " + application.VirtualDirectories[0].Path);
                    return false;
                }
                var physicalPath = System.IO.Path.Combine(branchPath, appConfig.FsPath);
                if (application.VirtualDirectories[0].PhysicalPath != physicalPath)
                {
                    Debug.WriteLine("Expected physical path to be '"+physicalPath+"' but found '"+application.VirtualDirectories[0].PhysicalPath+"'");
                    return false;
                }
            }
            return true;
        }

        public void ConfigureSites(string branchPath)
        {
            try
            {
                foreach (var site in _manager.Sites)
                {
                    site.Stop();
                }
            }
            catch (Exception e)
            {
                int i = 0;
            }
            foreach (var site in _manager.Sites.Where(site => WebSiteConfigs.ContainsKey(site.Name)))
            {
                ConfigureSite(branchPath, site);
            }
            SaveChanges();
            foreach (var site in _manager.Sites)
            {
                site.Start();
            }
            Reconnect();
        }

        private void ConfigureSite(string branchPath, Site site)
        {
            var websiteConfig = WebSiteConfigs[site.Name];
            var otherApplications = site.Applications.Where(app => !websiteConfig.WebApplicationConfigs.ContainsKey(app.Path));
            foreach (var otherApp in otherApplications)
            {
                Debug.WriteLine("Other Application Found: " + otherApp.Path);
            }
            var existingApplicationPaths = site.Applications.Where(app => websiteConfig.WebApplicationConfigs.ContainsKey(app.Path)).Select(app => app.Path);
            foreach (var application in site.Applications.Where(app => existingApplicationPaths.Contains(app.Path) && app.Path != "/").ToList())
            {
                site.Applications.Remove(application);
            }
            var rootAppConfig = websiteConfig.WebApplicationConfigs["/"];
            var rootApplication = site.Applications.First(app => app.Path == "/");
            var rootPhysicalPath = System.IO.Path.Combine(branchPath, rootAppConfig.FsPath);
            rootApplication.VirtualDirectories[0].PhysicalPath = rootPhysicalPath;
            foreach (var appConfig in websiteConfig.WebApplicationConfigs.Values.Where(val => val.WebPath != "/"))
            {
                var physicalPath = System.IO.Path.Combine(branchPath, appConfig.FsPath);
                site.Applications.Add(appConfig.WebPath, physicalPath);
                var application = site.Applications.First(app => app.Path == appConfig.WebPath);
                application.ApplicationPoolName = appConfig.AppPoolName;
            }
        }
    }
}
