using System;

namespace PM_IIS_Config_Manager
{
    public class UnableToDetectUserException : Exception
    {
    }
}