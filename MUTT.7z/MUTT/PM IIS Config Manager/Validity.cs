using System;

namespace PM_IIS_Config_Manager
{
    [Flags]
    public enum Validity
    {
        None = 0,
        Unknown = 1,
        UserName = 2,
        Password = 4,
    }
}