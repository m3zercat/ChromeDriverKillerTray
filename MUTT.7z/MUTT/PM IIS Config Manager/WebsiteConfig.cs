using System.Collections.Generic;

namespace PM_IIS_Config_Manager
{
    public class WebsiteConfig
    {
        public string Name { get; private set; }
        public List<int> StandardPorts { get; private set; }
        public List<int> SslPorts { get; private set; }
        public Dictionary<string, WebApplicationConfig> WebApplicationConfigs { get; private set; } 

        public WebsiteConfig(string name, string path)
        {
            Name = name;
            StandardPorts = new List<int>();
            SslPorts = new List<int>();
            WebApplicationConfigs = new Dictionary<string, WebApplicationConfig>();
            var defaultApp = new WebApplicationConfig(@"/", path);
            WebApplicationConfigs.Add(defaultApp.WebPath, defaultApp);
        }

        public WebsiteConfig WithPorts(params int[] ports)
        {
            StandardPorts.AddRange(ports);
            return this;
        }

        public WebsiteConfig WithSslPorts(params int[] ports)
        {
            SslPorts.AddRange(ports);
            return this;
        }

        public WebsiteConfig WithWebDirectoryConfigs(params WebApplicationConfig[] webApplicationConfig)
        {
            foreach (var wdc in webApplicationConfig)
            {
                WebApplicationConfigs.Add(wdc.WebPath, wdc);
            }
            return this;
        }
    }
}