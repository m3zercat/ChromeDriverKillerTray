namespace PM_IIS_Config_Manager
{
    public class WebApplicationConfig
    {
        public string FsPath { get; private set; }
        public string WebPath { get; private set; }
        public string AppPoolName { get; private set; }

        public WebApplicationConfig(string webWebPath, string fsPath)
        {
            WebPath = webWebPath;
            FsPath = fsPath;
            AppPoolName = "DefaultAppPool";
        }
    }
}