﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PM_IIS_Config_Manager
{
    class IncorrectPasswordException : Exception
    {
    }
}
